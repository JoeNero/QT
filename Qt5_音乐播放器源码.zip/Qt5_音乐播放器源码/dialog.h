#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>
#include <QTimer>
namespace Ui {
class Dialog;
}

class Dialog : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog(QWidget *parent = 0);
    ~Dialog();
    int exit_type = 0;

private slots:
    void on_pushButton_clicked();
    void musicplayer_exit();
    void on_zuixiaohua_clicked();

    void on_tuichu_clicked();

private:
    Ui::Dialog *ui;
    QTimer *mytimer;
};

#endif // DIALOG_H
