#include "dialog.h"
#include "ui_dialog.h"

Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);
    mytimer = new QTimer;
    connect(mytimer,SIGNAL(timeout()),this,SLOT(musicplayer_exit()));
}

Dialog::~Dialog()
{
    delete ui;
}

void Dialog::on_pushButton_clicked()
{
    if(ui->pushButton->text() == "设置")
    {
        int hour,minute,second;
        hour = ui->hour->value();
        minute = ui->minute->value();
        second = ui->second->value();
        if(hour != 0 || minute != 0 || second != 0)
        {
            mytimer->start((hour*3600 + minute*60 + second)*1000);
            ui->pushButton->setText("取消设置");
        }
    }
    else if(ui->pushButton->text() == "取消设置")
    {
        mytimer->stop();
        ui->pushButton->setText("设置");
    }
}
void Dialog::musicplayer_exit()
{
    qApp->quit();
}

void Dialog::on_zuixiaohua_clicked()
{
    exit_type = 0;
}

void Dialog::on_tuichu_clicked()
{
    exit_type = 1;
}
