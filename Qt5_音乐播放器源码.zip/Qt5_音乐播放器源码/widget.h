#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QMediaPlayer>
#include <QtWinExtras>
#include <QFileDialog>
#include <QList>
#include <QDir>
#include <QTime>
#include <QDebug>
#include <QCloseEvent>
#include <QSystemTrayIcon>
#include <QMenu>
#include "dialog.h"

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();

private slots:

    void on_start_clicked();

    void on_pause_clicked();

    void on_stop_clicked();

    void on_add_clicked();

    void on_tableWidget_doubleClicked(const QModelIndex &index);

    void on_tableWidget_clicked(const QModelIndex &index);

    void updatePosition(qint64 position);

    void updateDuration(qint64 duration);

    void setPosition(int position);

    void on_verticalSlider_valueChanged(int value);

    void on_toolButton_clicked();

    void on_activatedSysTrayIcon(QSystemTrayIcon::ActivationReason reason);
protected:
    void closeEvent(QCloseEvent *event);

    void change_by_mode();//通过播放方式切换歌曲

    void creatActions();

    void creatTrayIcon();
private:
    Ui::Widget *ui;
    QMediaPlayer *mediaPlayer;
    QStringList filter;
    QList<QString> filePath;
    QString music_file_path;
    QString cur_music;
    int cur_index;
    int pause_flag;
    qint64 music_duration;
    QDir *dir;
    QSystemTrayIcon *mSysTrayIcon;
    QMenu *trayIconMenu;
    QAction *minimizeAction;
    QAction *maximizeAction;
    QAction *restoreAction;
    QAction *quitAction;
    Dialog *mysetting;
};

#endif // WIDGET_H
